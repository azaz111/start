import os
from time import sleep, time
import conf_bf
from glob import glob
from json import loads
from BIB_API import service_avtoriz
import pymysql , json ,subprocess
from sshtunnel import SSHTunnelForwarder
import time
import pymysql
from sshtunnel import SSHTunnelForwarder
from BIB_API import bot
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from sys import argv
from datetime import datetime
try:
   from tqdm import tqdm
except:
    os.system('pip install tqdm')
    from tqdm import tqdm

start_time = datetime.now()
limit_time = datetime.now()
osn_serv=int(argv[1])
osn_lim=int(argv[2])
path=conf_bf.server_name
tabl_json=conf_bf.tabl_json
sch_pereezdov=0
sch_smen_time=0

def service_avtoriz_v3(token='token.json'):# АВТОРИЗАЦИЯ  Drive API v3  
    SCOPES = [
    'https://www.googleapis.com/auth/cloud-platform',
    'https://www.googleapis.com/auth/drive',
    'https://www.googleapis.com/auth/cloud-platform',
    'https://www.googleapis.com/auth/iam',
    'https://www.googleapis.com/auth/cloudplatformprojects'
    ]
    creds = Credentials.from_authorized_user_file(token, SCOPES)
    service = build('drive', 'v3', credentials=creds)
    return service

def chek_drive(poisk):# Проверка диска на удаление
    service = service_avtoriz_v3()
    with open('Spisok_drive.txt', 'rb') as t:
      id_disk_prov=t.readlines()[poisk-1][:-1].decode('utf-8')
    print('Чекаем диск '+ id_disk_prov)
    new_grives = service.teamdrives().list(pageSize=100).execute() #
    drive_lsp = new_grives.get('teamDrives')
    #print(drive_lsp)
    for qqq in drive_lsp :
      #print(qqq['id'])
      if qqq['id'] == str(id_disk_prov):
         return True
    return False

def getConnection(): 
    connection = pymysql.connect(host='127.0.0.1', port=server.local_bind_port, user='chai_cred',
                      password='Q12w3e4003r!', database='credentals',
                      cursorclass=pymysql.cursors.DictCursor)
    return connection

def _get_token(num=2):
    server.start()
    mybd = getConnection()
    cur = mybd.cursor()
    cur.execute( f"SELECT * FROM {tabl_json} WHERE status = 'True' " ) # запросим все данные  
    rows = cur.fetchall()
    try:
       token_j2=json.loads(rows[0]['token_j'])
       with open('token%s.json' % num , 'w') as token:
           json.dump(token_j2,token)
   
       id_cred=rows[0]['id']
       id_progect=rows[0]['id_project']

       print('Записались  +++ ')
       cur.execute( f"UPDATE {tabl_json} set status = 'False' WHERE id = {id_cred} ") # Обнавление данных
       mybd.commit()
       mybd.close()
    except:
        id_progect=False
        print('w++++++++++++++++++++++++++++++++')
        bot("НЕТ СВОБОДНЫХ ПРОЕКТОВ" , [292529642,183787479])
    server.stop()
    return id_progect

def download_new_json(nomber_start):
    global sch_pereezdov
    global sch_smen_time
    global limit_time
    sch_pereezdov+=1
    sch_smen_time+=1
    if sch_smen_time>5 :
       print("Орем о лимите проектов ")
       bot("Превышен лимит проектов\nCервер: %s номер %s"% (conf_bf.server_name,osn_serv) , [292529642,183787479])
       sleep(1200)
    else:
      if (datetime.now()-limit_time).total_seconds() > 1800 :
         limit_time=datetime.now()
         sch_smen_time=0
    
    os.system('rm -R accounts')
    os.system('mkdir accounts')
    id_progect=_get_token()
    if id_progect == False:
      return False
    xxx=0
    while True:
       try:
           proc=subprocess.Popen(['python3', 'multifactory.py', '--download-keys', id_progect , '--token' , 'token2.json' ])
           proc.wait(timeout=20)
           print('Завершился')
           break
       except subprocess.TimeoutExpired:
           proc.terminate()
           sleep(5)
           print('Не завершился')
           os.system('rm -R accounts')
           os.system('mkdir accounts')
           process = subprocess.Popen(['python3', 'multifactory.py', '--delete-sas', id_progect ,'--token' , 'token2.json' ])
           process.wait()
           sleep(10)
           process = subprocess.Popen(['python3', 'multifactory.py', '--create-sas', id_progect ,'--token' , 'token2.json' ])
           process.wait()
           sleep(10)
           try:
              process = subprocess.Popen(['python3', 'multifactory.py', '--download-keys', id_progect , '--token' , 'token2.json'  ])
              process.wait(timeout=20)
              break
           except subprocess.TimeoutExpired:
              process.terminate()
              xxx+=1
              if xxx == 4 :
                 print(' хватит уже -------------')
                 return False
              else:
                 print('И повтоно не прокатило давай еще кружок')
                 
    pathn='accounts'
    for root, dirs, files in os.walk(pathn):
      for i in range(len(files)-5):
         try:
            os.remove(pathn+'/'+files[i])
         except:
            pass
    pathn
    print('Периименовываю ' + str(len(os.listdir(pathn)))+' файлов')
    for filename in os.listdir(pathn):
        os.rename(os.path.join(pathn,filename), os.path.join(pathn,str(nomber_start)+'.json'))
        nomber_start = nomber_start +1 
    return True
        
def countdown(text='',num_of_secs=10):
   while num_of_secs:
       m, s = divmod(num_of_secs, 60)
       min_sec_format = '{:02d}:{:02d}'.format(m, s)
       print(text + min_sec_format, end='\r')
       time.sleep(1)
       num_of_secs -= 1  

server = SSHTunnelForwarder(
    ('149.248.8.216', 22),
    ssh_username='root',
    ssh_password='XUVLWMX5TEGDCHDU',
    remote_bind_address=('127.0.0.1', 3306)
)

def pap_mount(name_osnova,nomber_osnova):
   try:
      sleep(2)
      sum_plot=len(os.listdir(f'/{name_osnova}/{nomber_osnova}-1.d'))
      sleep(2)
   except:
      sum_plot=0
   return sum_plot

def add_json_to_drive(id_drives):
   """ Привязываем джисоны к дискам """
   drive=service_avtoriz_v3()
   accounts_to_add = []
   path ='accounts'
   
   print('Считываем джисоны')
   for i in glob('%s/*.json' % path):
       accounts_to_add.append(loads(open(i, 'r').read())['client_email'])
   print('Привязываем %s штук'%len(accounts_to_add))
   for id_drive in id_drives: 
      for i in accounts_to_add:
         try:
            drive.permissions().create(fileId=id_drive, fields='emailAddress', supportsAllDrives=True, body={
                "role": "fileOrganizer",
                "type": "user",
                "emailAddress": i
            }).execute()
         except:
            print('------- Впоймали косяк с диском ------')
      print('Успешно привязаны')  

def cikl():
   list_nomber=list(range(osn_serv+1,osn_lim+1))
   print(list_nomber)
   """ Монтируем + Проверка """
   schet=0
   x=osn_serv
   q=0

   for iii in tqdm(list_nomber):
      name_osnova='osnova'+str(iii)
      x += 1
      if pap_mount(name_osnova,iii) >= 1 :
         pass
         #print(f'Диск {name_osnova} смонтирован ')
      else:
         print(f'Нет плотов {name_osnova} - , косяк')
         if chek_drive(iii) == False:
            print("\033[31m{}\033[0m".format('   ...диск удален '))
         else:
            print("\033[32m{}\033[0m".format('   ...диск на месте '))
            # качаем джисоны 
            if download_new_json(list_nomber[0]) == False:
               break
             
            # берем айди диска 
            id_disk_prov=[]
            for nnn in list_nomber:
               with open('Spisok_drive.txt', 'rb') as t:
                   id_disk_prov.append(t.readlines()[nnn-1][:-1].decode('utf-8'))
            # Отчистить привязки
            for id_disk_provs in id_disk_prov:
                os.system(f'python3 mas_dell.py -d {id_disk_provs}')
            # Привязать новые
            add_json_to_drive(id_disk_prov)
            
            #exit()
            for rrr in list_nomber:
               name_osnova='osnova'+str(rrr)
               while True:
                  if chek_drive(rrr) == False:
                     break
                  schet=schet+1
                  sleep(4)
                  os.system (f'fusermount -uz /{name_osnova}')
                  sleep(2)
                  os.system (f'screen -dmS "{name_osnova}" rclone mount {name_osnova}: /{name_osnova} --allow-non-empty --daemon --multi-thread-streams 1024 --multi-thread-cutoff 128M --vfs-read-chunk-size-limit off --buffer-size 0K --vfs-read-chunk-size 64K --vfs-read-wait 0ms -v --read-only')
                  print( 'Пытаюсь повторно размонтировать')
                  if pap_mount(name_osnova,rrr) >= 1 :
                     print(' Повторно прокатило')
                     schet=0
                     break
                  if schet == 4:
                     schet=0
                     break  
   
   print("\033[32m{}\033[0m".format(' ВЫПОЛНЕНО ! Монтирование ЗАВЕРШЕНо ! \n Смен проекта %s \n Время работы %s'% (sch_pereezdov,str(datetime.now() - start_time)[:-7])))


if __name__ == '__main__':
   while True:
      print('Приступаю к работе')
      cikl()
      countdown('Перерыв - ',120)




   

