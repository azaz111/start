osn_serv=10 # от
osn_lim=20 # До

server_name='yassel'
tabl_json='Project_baza'